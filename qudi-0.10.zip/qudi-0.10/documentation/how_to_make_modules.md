# How to create modules  {#make-modules}

## Decide on the structure


## Creating a hardware module

## Creating a logic module

## Creating a GUI module

## Creating an interface

## Creating an interfuse module