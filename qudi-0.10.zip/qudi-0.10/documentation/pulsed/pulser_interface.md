# Pulser Interface Explanation  {#pulser_interface}


## Constraints Explanation


## Active Channels

active channels



