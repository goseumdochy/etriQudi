# -*- coding: utf-8 -*-

"""
Control the Radiant Dyes flip mirror driver through the serial interface.

Qudi is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Qudi is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Qudi. If not, see <http://www.gnu.org/licenses/>.

Copyright (c) the Qudi Developers. See the COPYRIGHT.txt file at the
top-level directory of this distribution and at <https://github.com/Ulm-IQO/qudi/>
"""

import abc
from core.util.interfaces import InterfaceMetaclass


class SwitchInterface(metaclass=InterfaceMetaclass):
    """ Methods to control slow (mechaincal) laser switching devices. """

    _modtype = 'SwitchInterface'
    _modclass = 'interface'

    @abc.abstractmethod
    def getNumberOfSwitches(self):
        """ Gives the number of switches connected to this hardware.

          @return int: number of swiches on this hardware
        """
        pass

    @abc.abstractmethod
    def getSwitchState(self, switchNumber):
        """ Gives state of switch.

          @param int switchNumber: number of switch

          @return bool: True if on, False if off, None on error
        """
        pass

    @abc.abstractmethod
    def getCalibration(self, switchNumber, state):
        """ Get calibration parameter for switch.

          @param int switchNumber: number of switch for which to get calibration
                                   parameter
          @param str switchState: state ['On', 'Off'] for which to get
                                  calibration parameter

          @return str: calibration parameter fir switch and state.
        """
        pass

    @abc.abstractmethod
    def setCalibration(self, switchNumber, state, value):
        """ Set calibration parameter for switch.

          @param int switchNumber: number of switch for which to get calibration
                                   parameter
          @param str switchState: state ['On', 'Off'] for which to get
                                  calibration parameter
          @param int value: calibration parameter to be set.

          @return bool: True if suceeds, False otherwise
        """
        pass

    @abc.abstractmethod
    def switchOn(self, switchNumber):
        """ Switch on.

          @param int switchNumber: number of switch to be switched

          @return bool: True if suceeds, False otherwise
        """
        pass

    @abc.abstractmethod
    def switchOff(self, switchNumber):
        """ Switch off.

          @param int switchNumber: number of switch to be switched

          @return bool: True if suceeds, False otherwise
        """
        pass

    @abc.abstractmethod
    def getSwitchTime(self, switchNumber):
        """ Give switching time for switch.

          @param int switchNumber: number of switch

          @return float: time needed for switch state change
        """
        pass
